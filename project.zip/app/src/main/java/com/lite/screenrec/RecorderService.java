package com.lite.screenrec;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderService extends Service {
    static final String ACTION_START = "start", ACTION_STOP = "stop";
    static volatile boolean running;

    private static final String CHANNEL = "rec";
    private MediaProjection projection;
    private ScreenRecorder screen;
    private ParcelFileDescriptor pfd;
    private Uri uri;
    private PowerManager.WakeLock wakeLock;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || ACTION_STOP.equals(intent.getAction())) {
            stopRecording();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;

        // Foreground notification keeps Android from killing us mid-recording
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "Recording", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, RecorderService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        @SuppressWarnings("deprecation")
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Recording screen")
                .setContentIntent(open)
                .addAction(android.R.drawable.ic_media_pause, "Stop", stop)
                .setOngoing(true)
                .build();
        int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
        if (intent.getBooleanExtra("audio", false)) {
            type |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE; // lets Android deliver real audio, not silence
        }
        startForeground(1, n, type);

        try {
            begin(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Recording failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            cleanup(false);
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @SuppressWarnings("deprecation")
    private void begin(Intent in) throws Exception {
        int fps = in.getIntExtra("fps", 30);
        int shortSide = in.getIntExtra("short", 360);
        int sw = in.getIntExtra("sw", 1080), sh = in.getIntExtra("sh", 1920);

        // Keep the screen's aspect ratio; long side aligned to 8 for encoder happiness
        boolean land = sw > sh;
        float ar = (float) Math.max(sw, sh) / Math.min(sw, sh);
        int longSide = Math.round(shortSide * ar / 8f) * 8;
        int w = land ? longSide : shortSide;
        int h = land ? shortSide : longSide;
        int bitrate = (int) (w * (long) h * fps * 0.09);

        PowerManager pm = getSystemService(PowerManager.class);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "screenrec:rec");
        wakeLock.acquire();

        String name = "REC_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".mp4";
        ContentValues v = new ContentValues();
        v.put(MediaStore.Video.Media.DISPLAY_NAME, name);
        v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenRec");
        v.put(MediaStore.Video.Media.IS_PENDING, 1);
        uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
        pfd = getContentResolver().openFileDescriptor(uri, "rw");

        MediaProjectionManager mpm = getSystemService(MediaProjectionManager.class);
        projection = mpm.getMediaProjection(in.getIntExtra("code", 0), (Intent) in.getParcelableExtra("data"));
        // Required on Android 14+, also finalizes the file if the system revokes capture
        projection.registerCallback(new MediaProjection.Callback() {
            @Override
            public void onStop() {
                stopRecording();
                stopSelf();
            }
        }, new Handler(Looper.getMainLooper()));

        screen = new ScreenRecorder(projection, pfd.getFileDescriptor(), w, h,
                getResources().getDisplayMetrics().densityDpi, fps, bitrate,
                in.getBooleanExtra("audio", false));
        screen.start();
        running = true;

        if (in.getBooleanExtra("audio", false)) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                ScreenRecorder r = screen;
                if (r != null && r.audioError() != null) {
                    Toast.makeText(this, "No audio: " + r.audioError(), Toast.LENGTH_LONG).show();
                }
            }, 2000);
        }
    }

    private synchronized void stopRecording() {
        if (!running) return;
        running = false;
        boolean ok = screen != null && screen.stop();
        screen = null;
        cleanup(ok);
    }

    private void cleanup(boolean keep) {
        try { if (projection != null) projection.stop(); } catch (Exception ignored) { }
        try { if (pfd != null) pfd.close(); } catch (Exception ignored) { }
        if (uri != null) {
            if (keep) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Video.Media.IS_PENDING, 0);
                getContentResolver().update(uri, v, null, null);
            } else {
                getContentResolver().delete(uri, null, null);
            }
        }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        projection = null; pfd = null; uri = null; wakeLock = null;
    }

    @Override
    public void onDestroy() {
        stopRecording();
        super.onDestroy();
    }
}
