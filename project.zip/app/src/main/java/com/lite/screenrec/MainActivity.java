package com.lite.screenrec;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 1, REQ_PERMS = 2;
    private RadioGroup fpsGroup, resGroup;
    private CheckBox audioBox;
    private Button btn;
    private TextView logView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p, p, p);

        root.addView(label("Frame rate"));
        fpsGroup = radios("30 FPS", "60 FPS");
        root.addView(fpsGroup);

        root.addView(label("Resolution"));
        resGroup = radios("360p", "720p");
        root.addView(resGroup);

        audioBox = new CheckBox(this);
        audioBox.setText("Record internal audio");
        audioBox.setChecked(true);
        audioBox.setPadding(0, 24, 0, 24);
        root.addView(audioBox);

        btn = new Button(this);
        btn.setOnClickListener(v -> onButton());
        root.addView(btn);

        logView = new TextView(this);
        logView.setTextSize(11);
        logView.setTextIsSelectable(true);
        logView.setPadding(0, 48, 0, 0);
        root.addView(logView);

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        btn.setText(RecorderService.running ? "Stop recording" : "Start recording");
        logView.setText("--- last session log ---\n" + Diag.get(this)
                + "--- why Android last ended this app ---\n" + exitInfo());
    }

    @TargetApi(30)
    private String exitInfo() {
        if (Build.VERSION.SDK_INT < 30) return "(needs Android 11+)\n";
        StringBuilder sb = new StringBuilder();
        try {
            ActivityManager am = getSystemService(ActivityManager.class);
            List<ApplicationExitInfo> l = am.getHistoricalProcessExitReasons(getPackageName(), 0, 3);
            for (ApplicationExitInfo i : l) {
                sb.append(new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date(i.getTimestamp())))
                        .append("  ").append(reasonName(i.getReason()))
                        .append(i.getDescription() == null ? "" : " - " + i.getDescription())
                        .append("\n");
            }
        } catch (Exception e) {
            sb.append("(unavailable)\n");
        }
        return sb.length() == 0 ? "(none)\n" : sb.toString();
    }

    private static String reasonName(int r) {
        switch (r) {
            case 1: return "EXIT_SELF";
            case 2: return "SIGNALED (killed)";
            case 3: return "LOW_MEMORY";
            case 4: return "CRASH (Java)";
            case 5: return "CRASH_NATIVE";
            case 6: return "ANR (not responding)";
            case 7: return "INITIALIZATION_FAILURE";
            case 8: return "PERMISSION_CHANGE";
            case 9: return "EXCESSIVE_RESOURCE_USAGE";
            case 10: return "USER_REQUESTED";
            case 11: return "USER_STOPPED";
            case 12: return "DEPENDENCY_DIED";
            case 13: return "OTHER";
            case 14: return "FREEZER";
            default: return "reason " + r;
        }
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(18);
        t.setPadding(0, 24, 0, 8);
        return t;
    }

    private RadioGroup radios(String... items) {
        RadioGroup g = new RadioGroup(this);
        for (String s : items) {
            RadioButton r = new RadioButton(this);
            r.setId(View.generateViewId());
            r.setText(s);
            g.addView(r);
        }
        g.check(g.getChildAt(0).getId());
        return g;
    }

    private int selected(RadioGroup g) {
        return g.indexOfChild(g.findViewById(g.getCheckedRadioButtonId()));
    }

    private boolean granted(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void onButton() {
        if (RecorderService.running) {
            startService(new Intent(this, RecorderService.class)
                    .setAction(RecorderService.ACTION_STOP));
            btn.setText("Start recording");
            return;
        }
        ArrayList<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (audioBox.isChecked() && !granted(Manifest.permission.RECORD_AUDIO))
            need.add(Manifest.permission.RECORD_AUDIO);
        if (need.isEmpty()) launchCapture();
        else requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ_PERMS) {
            if (audioBox.isChecked() && !granted(Manifest.permission.RECORD_AUDIO)) {
                Toast.makeText(this, "Audio permission denied - recording video only. "
                        + "Enable 'Microphone' for this app in system settings.", Toast.LENGTH_LONG).show();
            }
            launchCapture(); // denied audio = video-only, still records
        }
    }

    private void launchCapture() {
        MediaProjectionManager m = getSystemService(MediaProjectionManager.class);
        startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAPTURE || res != RESULT_OK) return;

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);

        Intent i = new Intent(this, RecorderService.class)
                .setAction(RecorderService.ACTION_START)
                .putExtra("code", res)
                .putExtra("data", data)
                .putExtra("fps", selected(fpsGroup) == 1 ? 60 : 30)
                .putExtra("short", selected(resGroup) == 1 ? 720 : 360)
                .putExtra("audio", audioBox.isChecked() && granted(Manifest.permission.RECORD_AUDIO))
                .putExtra("sw", dm.widthPixels)
                .putExtra("sh", dm.heightPixels);
        startForegroundService(i);
        finish(); // get out of the way so you can go play
    }
}
