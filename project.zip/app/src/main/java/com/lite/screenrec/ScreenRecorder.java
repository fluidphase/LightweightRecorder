package com.lite.screenrec;

import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.projection.MediaProjection;
import android.view.Surface;

import java.io.FileDescriptor;
import java.nio.ByteBuffer;

/** Hardware H.264 (surface) + AAC internal audio -> MP4. Video-only if audio can't start. */
final class ScreenRecorder {
    private static final int RATE = 44100;

    private final MediaProjection projection;
    private final FileDescriptor fd;
    private final int w, h, dpi, fps, bitrate;
    private boolean hasAudio;

    private MediaMuxer muxer;
    private MediaCodec vEnc, aEnc;
    private AudioRecord audioRec;
    private VirtualDisplay display;
    private Thread vThread, aThread;
    private long t0;

    private int tracksAdded;
    private boolean videoAdded, started, aborted;
    private volatile boolean stopRequested, failed;
    private volatile String audioError;

    String audioError() { return audioError; }

    ScreenRecorder(MediaProjection p, FileDescriptor fd, int w, int h, int dpi,
                   int fps, int bitrate, boolean audio) {
        this.projection = p; this.fd = fd; this.w = w; this.h = h;
        this.dpi = dpi; this.fps = fps; this.bitrate = bitrate; this.hasAudio = audio;
    }

    void start() throws Exception {
        try {
            muxer = new MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

            MediaFormat vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h);
            vf.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            vf.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            vf.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
            vf.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            vEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC);
            vEnc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            Surface surface = vEnc.createInputSurface();
            vEnc.start();

            if (hasAudio && !setupAudio()) hasAudio = false;

            t0 = System.nanoTime() / 1000;
            display = projection.createVirtualDisplay("rec", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null);

            vThread = new Thread(this::videoLoop, "rec-video");
            vThread.start();
            if (hasAudio) {
                aThread = new Thread(this::audioLoop, "rec-audio");
                aThread.start();
            }
        } catch (Exception e) {
            stop();
            throw e;
        }
    }

    private boolean setupAudio() {
        try {
            AudioPlaybackCaptureConfiguration cfg = new AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build();
            AudioFormat af = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(RATE)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build();
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT);
            audioRec = new AudioRecord.Builder()
                    .setAudioFormat(af)
                    .setBufferSizeInBytes(Math.max(min, 4096) * 4)
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
            if (audioRec.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException();

            MediaFormat f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, RATE, 2);
            f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            f.setInteger(MediaFormat.KEY_BIT_RATE, 96000);
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 8192);
            aEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            aEnc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            aEnc.start();
            return true;
        } catch (Exception e) {
            audioError = e.getClass().getSimpleName() + ": " + e.getMessage();
            try { if (audioRec != null) audioRec.release(); } catch (Exception ignored) { }
            try { if (aEnc != null) aEnc.release(); } catch (Exception ignored) { }
            audioRec = null; aEnc = null;
            return false;
        }
    }

    // ---- muxer coordination -------------------------------------------------

    private synchronized int addTrack(MediaFormat f, boolean video) {
        int t = muxer.addTrack(f);
        tracksAdded++;
        if (video) videoAdded = true;
        if (!started && videoAdded && tracksAdded >= (hasAudio ? 2 : 1)) {
            muxer.start();
            started = true;
            notifyAll();
        }
        return t;
    }

    private synchronized boolean awaitStart() {
        while (!started && !aborted) {
            try { wait(200); } catch (InterruptedException e) { return false; }
        }
        return started;
    }

    private synchronized void write(int track, ByteBuffer buf, MediaCodec.BufferInfo bi) {
        buf.position(bi.offset);
        buf.limit(bi.offset + bi.size);
        muxer.writeSampleData(track, buf, bi);
    }

    private synchronized void audioFailed() {
        hasAudio = false; // carry on with video only
        try {
            if (!started && videoAdded) { muxer.start(); started = true; }
        } catch (Exception e) {
            failed = true;
        }
        notifyAll();
    }

    // ---- encoder loops ------------------------------------------------------

    private void videoLoop() {
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        int track = -1;
        try {
            while (true) {
                int i = vEnc.dequeueOutputBuffer(bi, 10000);
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = addTrack(vEnc.getOutputFormat(), true);
                } else if (i >= 0) {
                    ByteBuffer buf = vEnc.getOutputBuffer(i);
                    if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0;
                    if (bi.size > 0 && track >= 0 && awaitStart()) {
                        bi.presentationTimeUs = Math.max(0, bi.presentationTimeUs - t0);
                        write(track, buf, bi);
                    }
                    vEnc.releaseOutputBuffer(i, false);
                    if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
                }
            }
        } catch (Exception e) {
            failed = true;
        }
    }

    private void audioLoop() {
        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
        int track = -1;
        long frames = 0, startUs = -1;
        boolean eosSent = false, done = false;
        try {
            audioRec.startRecording();
            while (!done) {
                if (!eosSent) {
                    int ii = aEnc.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer in = aEnc.getInputBuffer(ii);
                        in.clear();
                        if (stopRequested) {
                            long pts = Math.max(0, (startUs < 0 ? 0 : startUs - t0) + frames * 1000000L / RATE);
                            aEnc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            eosSent = true;
                        } else {
                            int n = audioRec.read(in, Math.min(in.capacity(), 4096));
                            if (n < 0) throw new RuntimeException("audio read " + n);
                            if (n > 0 && startUs < 0) {
                                startUs = System.nanoTime() / 1000 - (n / 4) * 1000000L / RATE;
                            }
                            long pts = Math.max(0, (startUs < 0 ? 0 : startUs - t0) + frames * 1000000L / RATE);
                            frames += n / 4;
                            aEnc.queueInputBuffer(ii, 0, n, pts, 0);
                        }
                    }
                }
                while (true) {
                    int o = aEnc.dequeueOutputBuffer(bi, 0);
                    if (o == MediaCodec.INFO_TRY_AGAIN_LATER) break;
                    if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = addTrack(aEnc.getOutputFormat(), false);
                    } else if (o >= 0) {
                        ByteBuffer buf = aEnc.getOutputBuffer(o);
                        if ((bi.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) bi.size = 0;
                        if (bi.size > 0 && track >= 0 && awaitStart()) write(track, buf, bi);
                        aEnc.releaseOutputBuffer(o, false);
                        if ((bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) { done = true; break; }
                    }
                }
            }
        } catch (Exception e) {
            audioError = e.getClass().getSimpleName() + ": " + e.getMessage();
            audioFailed();
        }
    }

    // ---- stop ---------------------------------------------------------------

    /** Finalizes the MP4. Returns true if the file is valid and worth keeping. */
    boolean stop() {
        stopRequested = true;
        try { if (display != null) display.release(); } catch (Exception ignored) { }
        try { if (vEnc != null) vEnc.signalEndOfInputStream(); } catch (Exception e) { failed = true; }
        join(vThread);
        join(aThread);
        synchronized (this) { aborted = true; notifyAll(); }

        boolean ok = started && !failed;
        try { if (audioRec != null) audioRec.stop(); } catch (Exception ignored) { }
        try { if (audioRec != null) audioRec.release(); } catch (Exception ignored) { }
        try { if (aEnc != null) { aEnc.stop(); aEnc.release(); } } catch (Exception ignored) { }
        try { if (vEnc != null) { vEnc.stop(); vEnc.release(); } } catch (Exception ignored) { }
        try { if (started) muxer.stop(); } catch (Exception e) { ok = false; }
        try { if (muxer != null) muxer.release(); } catch (Exception ignored) { }
        return ok;
    }

    private static void join(Thread t) {
        try { if (t != null) t.join(3000); } catch (InterruptedException ignored) { }
    }
}
