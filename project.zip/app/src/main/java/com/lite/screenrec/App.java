package com.lite.screenrec;

import android.app.Application;
import android.util.Log;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            String s = Log.getStackTraceString(e);
            if (s.length() > 700) s = s.substring(0, 700);
            Diag.add(this, "CRASH on thread " + t.getName() + ": " + s);
            if (prev != null) prev.uncaughtException(t, e);
        });
    }
}
