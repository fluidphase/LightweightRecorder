package com.lite.screenrec;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Tiny persistent event log so we can see why a recording ended. */
final class Diag {
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("diag", 0);
    }

    static synchronized void add(Context c, String msg) {
        String line = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + "  " + msg + "\n";
        String all = sp(c).getString("log", "") + line;
        if (all.length() > 4000) all = all.substring(all.length() - 4000);
        sp(c).edit().putString("log", all).commit(); // commit: must survive a crash
    }

    static void heartbeat(Context c, long seconds) {
        sp(c).edit().putLong("hb", seconds).commit();
    }

    static String get(Context c) {
        long hb = sp(c).getLong("hb", -1);
        return sp(c).getString("log", "(empty)")
                + (hb >= 0 ? "last heartbeat: " + hb + "s into recording\n" : "");
    }

    static void clear(Context c) {
        sp(c).edit().clear().commit();
    }
}
