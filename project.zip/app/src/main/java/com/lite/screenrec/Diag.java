package com.lite.screenrec;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Tiny persistent event log so we can see why a recording ended. */
final class Diag {
    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("diag", 0);
    }

    static synchronized void add(Context c, String msg) {
        String line = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + "  " + msg + "\n";
        String all = sp(c).getString("log", "") + line;
        if (all.length() > 4000) all = all.substring(all.length() - 4000);
        sp(c).edit().putString("log", all).commit(); // commit: must survive a crash
    }

    static synchronized void heartbeat(Context c, String line) {
        String all = sp(c).getString("hb", "") + line + "\n";
        String[] parts = all.split("\n");
        StringBuilder sb = new StringBuilder();
        for (int i = Math.max(0, parts.length - 4); i < parts.length; i++) sb.append(parts[i]).append("\n");
        sp(c).edit().putString("hb", sb.toString()).apply();
    }

    static String get(Context c) {
        String hb = sp(c).getString("hb", "");
        return sp(c).getString("log", "(empty)")
                + (hb.isEmpty() ? "" : "last heartbeats:\n" + hb);
    }

    static void clear(Context c) {
        sp(c).edit().clear().commit();
    }
}
